@extends('errors::minimal')

@section('title', __('Page Expired'))


@section('page_custom')
    <div>
        <h1 class="error_title">Page Expired!</h1>        
    </div>
    
@endsection