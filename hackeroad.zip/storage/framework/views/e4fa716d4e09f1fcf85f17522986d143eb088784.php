<!DOCTYPE html><!--[if IE 8 ]>
    <html lang="en" class="no-js ie8"></html><![endif]-->
    <!--[if IE 9 ]>
    <html lang="en" class="no-js ie9"></html><![endif]-->
    <html class="no-js" lang="en">
      
    <head>
        <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-158365058-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'UA-158365058-1');
    </script>
    
        <meta charset="UTF-8">
        <meta name="description" content="Face Mask 99 - Protect Yourself From Viruses By Buying The Best Mask For Protection | N99 + N95 + M3 + Kids Mask">
        <meta name="author" content="RASBULA.com By RBS">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, maximum-scale=1, shrink-to-fit=no">
        <meta name="format-detection" content="telephone=no">
        <script src="cdn-cgi/apps/head/sxN6HgCn8v7CG45Nsym8imDXilk.js"></script><link rel="shortcut icon" href="assets/images/products/favicon.png">
        <link rel="apple-touch-icon" href="assets/images/demo-content/favicon.png">
        <title>TERMS FACE MASK N99 - Protect Yourself From Viruses Today (Inculde CORONA COVID-19 Virus)</title>
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="assets/css/style.css"><!--[if lt IE 9]>
        <script src="assets/js/html5shiv.min.js"></script>
        <script src="assets/js/respond.min.js"></script>
        <script src="assets/js/es5-shim.min.js"></script><![endif]-->
     <style type="text/css">
          .navbar-default .navbar-nav>.order_li>a:before, .navbar-default .navbar-nav>.order_li>a:after {
       border:none !important;
    }
    .selectize-dropdown, .selectize-input, .selectize-input input {
        color: #303030;
        font-family: inherit;
        font-size: 10px !important;
        line-height: 18px;
    }
    .form-control, output {
        font-size: 10px !important;
        line-height: 1.42857;
        color: #555;
        display: block;
    }
    .ct-iconBox.ct-iconBox--type3 .media-body .ct-iconBox-description {
        font-weight: 700;
        font-size: 14px !important;
    }
    .ct-iconBox.ct-iconBox--type3 .media-body .ct-iconBox-title {
        font-size: 18px !important;
    }
    
    
    
    .btn-group.btn-group--separated .btn-lg:first-child {
        padding: 20px 23px !important;
    }
    .btn-group.btn-group--separated {
        margin: 0 0px !important;
    }
    .btn-group.btn-group--separated .btn-lg {
        font-size: 11px !important;  
    }
    
    
    .ct-cart {
        width: 250px;
        right: 4px !important;
    }
    
    @media  only screen and (max-width: 991px){
    .navbar.navbar-dark {
        background-color: #fff !important;
    }
    .navbar.navbar-dark .nav.navbar-nav li a {
        padding: 0;
        margin: 10px 40px 10px 0;
        color: #000 !important;
        cursor: pointer;
    }
    .mobile_repon_icon{
     padding-left:0px !important;
    }
    .pad_respo{
      padding-right:0px !important;
    }
    
    }
    
    @media  only screen and (min-width: 992px){
    
    .margin_left{
      margin-left:-49px;
    }
    
    }
    
    
    
    @media  only screen and (min-width: 1200px){
    .ct-dividerSection.ct-dividerSection--currency .ct-dividerSection--right {
        text-align: left !important;
    }
    .ct-dividerSection.ct-dividerSection--currency .ct-contactForm.form-inline .form-group {
        padding: 0px 10px !important;
    }
    .ct-dividerSection.ct-dividerSection--currency .form-control, .ct-dividerSection.ct-dividerSection--currency .selectize-control {
        width: 188px !important;
    }
    
    }
    /*@media  only screen and (min-width: 768px){
    .ct-cart__button {
        display: block;
        position: absolute;
        background-color: #fff;
        text-align: center;
        cursor: pointer;
        height: 44px !important;
        width: 132px !important;
        top: 0;
        left: -91px !important;
        font-size: 20px;
        font-size: 2rem;
        line-height: 40px;
        box-shadow: 0px 0px 4px 0px rgba(0,0,0,0.3);
        z-index: 1;
        transform: rotate(270deg) !important;
    }
    }*/
    @media  only screen and (max-width: 767px){
    .slide_head{
        font-size:35px !important;
    }
    .slide_head2{
      font-size:25px !important;
    }
    .slide_bottom_pad{
      padding-bottom:50px;
      padding-top:20px;
    }
    .ct-mediaBox-poster{
      display: none !important;
    }
    .margin_left{
      margin-left:-23px !important;
    }
    
    }
    
    @media  only screen and (max-width: 414px){
    .pad_respo{
      padding-right:0px !important;
      padding-left:138px;
    }
    
    }
    
    
    
    
        </style>
    
      </head>
      <body class="cssAnimate smartwatch navigation-wide">
    
        <section class="ct-u-padding-top-70" id="terms" style="padding:50px;"><br><br><br><br>
    
    <center><h1 style="box-sizing: border-box; font-size: 24px; margin: 0px 0px 1em; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; line-height: 1.1; color: rgb(51, 51, 51);">Terms and Conditions for FaceMask99.com</h1></center>
    <h2 style="box-sizing: border-box; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; line-height: 1.1; color: rgb(51, 51, 51); margin: 0px 0px 1em; font-size: 20px;">Introduction</h2>
    <p style="box-sizing: border-box; margin: 1em 0px; color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px;">These Website Standard Terms and Conditions written on this webpage shall manage your use of our website, <span class="gmail-highlight gmail-preview_website_name" style="box-sizing: border-box; background: rgb(255, 255, 238);">Face Mask 99</span> accessible at <span class="gmail-highlight gmail-preview_website_url" style="box-sizing: border-box; background: rgb(255, 255, 238);">facemask99.com</span>.</p>
    <p style="box-sizing: border-box; margin: 1em 0px; color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px;">These Terms will be applied fully and affect to your use of this Website. By using this Website, you agreed to accept all terms and conditions written in here. You must not use this Website if you disagree with any of these Website Standard Terms and Conditions.</p>
    <p style="box-sizing: border-box; margin: 1em 0px; color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px;">Minors or people below 16 years old are not allowed to use this Website Services.</p>
    <h2 style="box-sizing: border-box; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; line-height: 1.1; color: rgb(51, 51, 51); margin: 0px 0px 1em; font-size: 20px;">Intellectual Property Rights</h2>
    <p style="box-sizing: border-box; margin: 1em 0px; color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px;">Other than the content you own, under these Terms, &nbsp;
    Face Mask 99 &nbsp;and/or its licensors own all the intellectual property rights and materials contained in this Website.</p>
    <p style="box-sizing: border-box; margin: 1em 0px; color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px;">You are granted limited license only for purposes of viewing the material contained on this Website.</p>
    <h2 style="box-sizing: border-box; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; line-height: 1.1; color: rgb(51, 51, 51); margin: 0px 0px 1em; font-size: 20px;">Restrictions</h2>
    <p style="box-sizing: border-box; margin: 1em 0px; color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px;">You are specifically restricted from all of the following:</p>
    <ul style="box-sizing: border-box; margin: 1em 0px; padding: 0px 0px 0px 1em; list-style-position: outside; color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px;">
      <li style="box-sizing: border-box; margin-top: 0.5em; margin-bottom: 0.5em;">publishing any Website material in any other media;</li>
      <li style="box-sizing: border-box; margin-top: 0.5em; margin-bottom: 0.5em;">selling, sublicensing and/or otherwise commercializing any Website material;</li>
      <li style="box-sizing: border-box; margin-top: 0.5em; margin-bottom: 0.5em;">publicly performing and/or showing any Website material;</li>
      <li style="box-sizing: border-box; margin-top: 0.5em; margin-bottom: 0.5em;">using this Website in any way that is or may be damaging to this Website;</li>
      <li style="box-sizing: border-box; margin-top: 0.5em; margin-bottom: 0.5em;">using this Website in any way that impacts user access to this Website;</li>
      <li style="box-sizing: border-box; margin-top: 0.5em; margin-bottom: 0.5em;">using this Website contrary to applicable laws and regulations, or in any way may cause harm to the Website, or to any person or business entity;</li>
      <li style="box-sizing: border-box; margin-top: 0.5em; margin-bottom: 0.5em;">engaging in any data mining, data harvesting, data extracting or any other similar activity in relation to this Website;</li>
      <li style="box-sizing: border-box; margin-top: 0.5em; margin-bottom: 0.5em;">using this Website to engage in any advertising or marketing.</li>
    
    </ul>
    <p style="box-sizing: border-box; margin: 1em 0px; color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px;">Certain areas of this Website are restricted from being access by you and <span class="gmail-highlight gmail-preview_company_name" style="box-sizing: border-box; background: rgb(255, 255, 238);">Face Mask 99</span> may further restrict access by you to any areas of this Website, at any time, in absolute discretion. Any user ID and password you may have for this Website are confidential and you must maintain confidentiality as well.</p>
    <h2 style="box-sizing: border-box; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; line-height: 1.1; color: rgb(51, 51, 51); margin: 0px 0px 1em; font-size: 20px;">Orders &amp; Shipping</h2>
    <h2 style="box-sizing: border-box; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; line-height: 1.1; color: rgb(51, 51, 51); margin: 0px 0px 1em; font-size: 20px;">
      <p style="box-sizing: border-box; margin: 1em 0px; font-size: 16px;"><span style="font-weight: 400;">Each User from all over the world is allowed to make order of masks from facemask99.com website and the buyer need to understand that facemask99.com is using third parties to ship the order and cannot control the timeframe of the order made and from that reason Face Mask 99 Team will&nbsp;</span><span style="font-weight: normal;">guarantee the supply within 90 days and if in any case after 90 days the package didnt arrived &nbsp;to the buyer destination then Face Mask 99 Team will refund 100% of the total amount paid as the shippijng company might lost it on the way and or the package delivery is delayed due to worldwide crises like the corona virus as known as Covid-19 virus and due to that situation and for the rist taken by all parties face mask 99 will insure and cover 100% of package cost and incase after 90 days the package didnt arrived n buyer destination the buyer will get refund of 100% and no more or less.&nbsp;</span></p>
      <p style="box-sizing: border-box; margin: 1em 0px; font-size: 16px;"><span style="font-weight: 400;">all images in the website should be similar to the masks provided but in some cases it can be a bit different as manufacrurers are changeble and some produde the items in a bit different design but the quality of the goods will remain the same or better.</span></p>
      <p style="box-sizing: border-box; margin: 1em 0px; font-size: 16px;"><span style="font-weight: 400;">all orders and paymants are made on seller website (facemask99.com) and buyer cannot claim for a refund before 90 days have passed and in case package didnt arrived after 90 days the buyer will get 10
      0% refund from facemask99.com team as compensation for the package lost or delayed. in some cases the reason for package delayed or lost is local post office fault or shipping company lost and facemaks99.com team cannot control those third parties and due to that the refund is 100% only</span></p>
      <p style="box-sizing: border-box; margin: 1em 0px; font-size: 16px;"><span style="font-weight: 400;">buyer is not allowed to file claims in paypal before 90 days have passed as face mask 99 team have shipped the products and waiting for it to be delivered.&nbsp;</span></p>
      <p style="box-sizing: border-box; margin: 1em 0px; font-size: 16px;"><span style="font-weight: 400;">tracking numbers will be provided if exist but in some cases will not be provided as face mask team is doing bulk shippments and cannot operate control with shipping companies that are overloaded in the corona virus periods&nbsp;/ also please note that process order can take up to 14 days due to overloaded work</span></p>
    </h2>
    <h2 style="box-sizing: border-box; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; line-height: 1.1; color: rgb(51, 51, 51); margin: 0px 0px 1em; font-size: 20px;">Your Content</h2>
    <p style="box-sizing: border-box; margin: 1em 0px; color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px;">In these Website Standard Terms and Conditions, “Your Content” shall mean any audio, video text, images or other material you choose to display on this Website. By displaying Your Content, you grant <span class="gmail-highlight gmail-preview_company_name" style="box-sizing: border-box; background: rgb(255, 255, 238);">&nbsp;Face Mask 99&nbsp;</span> a non-exclusive, worldwide irrevocable, sub licensable license to use, reproduce, adapt, publish, translate and distribute it in any and all media.</p>
    <p style="box-sizing: border-box; margin: 1em 0px; color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px;">Your Content must be your own and must not be invading any third-party's rights. <span class="gmail-highlight gmail-preview_company_name" style="box-sizing: border-box; background: rgb(255, 255, 238);">&nbsp;Face Mask 99&nbsp;</span> reserves the right to remove any of Your Content from this Website at any time without notice.</p>
    <h2 style="box-sizing: border-box; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; line-height: 1.1; color: rgb(51, 51, 51); margin: 0px 0px 1em; font-size: 20px;">No warranties</h2>
    <p style="box-sizing: border-box; margin: 1em 0px; color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px;">This Website is provided “as is,” with all faults, and <span class="gmail-highlight gmail-preview_company_name" style="box-sizing: border-box; background: rgb(255, 255, 238);">&nbsp;Face Mask 99&nbsp;</span> express no representations or warranties, of any kind related to this Website or the materials contained on this Website. Also, nothing contained on this Website shall be interpreted as advising you.</p>
    <h2 style="box-sizing: border-box; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; line-height: 1.1; color: rgb(51, 51, 51); margin: 0px 0px 1em; font-size: 20px;">Limitation of liability</h2>
    <p style="box-sizing: border-box; margin: 1em 0px; color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px;">In no event shall <span class="gmail-highlight gmail-preview_company_name" style="box-sizing: border-box; background: rgb(255, 255, 238);">&nbsp;Face Mask 99&nbsp;</span>, nor any of its officers, directors and employees, shall be held liable for anything arising out of or in any way connected with your use of this Website whether such liability is under contract. &nbsp;<span class="gmail-highlight gmail-preview_company_name" style="box-sizing: border-box; background: rgb(255, 255, 238);">&nbsp;Face Mask 99&nbsp;</span>, including its officers, directors and employees shall not be held liable for any indirect, consequential or special liability arising out of or in any way related to your use of this Website.</p>
    <h2 style="box-sizing: border-box; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; line-height: 1.1; color: rgb(51, 51, 51); margin: 0px 0px 1em; font-size: 20px;">Indemnification
      <p style="box-sizing: border-box; margin: 1em 0px;">
        <br>
    
      </p>
      <p style="box-sizing: border-box; margin: 1em 0px;">You hereby indemnify to the fullest extent <span class="gmail-highlight gmail-preview_company_name" style="box-sizing: border-box; background: rgb(255, 255, 238);">Face Mask 99</span> from and against any and/or all liabilities, costs, demands, causes of action, damages and expenses arising in any way related to your breach of any of the provisions of these Terms.</p>
    </h2>
    <h2 style="box-sizing: border-box; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; line-height: 1.1; color: rgb(51, 51, 51); margin: 0px 0px 1em; font-size: 20px;">Severability</h2>
    <p style="box-sizing: border-box; margin: 1em 0px; color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px;">If any provision of these Terms is found to be invalid under any applicable law, such provisions shall be deleted without affecting the remaining provisions herein.</p>
    <h2 style="box-sizing: border-box; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; line-height: 1.1; color: rgb(51, 51, 51); margin: 0px 0px 1em; font-size: 20px;">Variation of Terms</h2>
    <p style="box-sizing: border-box; margin: 1em 0px; color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px;"><span class="gmail-highlight gmail-preview_company_name" style="box-sizing: border-box; background: rgb(255, 255, 238);">&nbsp;Face Mask 99&nbsp;</span> is permitted to revise these Terms at any time as it sees fit, and by using this Website you are expected to review these Terms on a regular basis.</p>
    <h2 style="box-sizing: border-box; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; line-height: 1.1; color: rgb(51, 51, 51); margin: 0px 0px 1em; font-size: 20px;">Assignment</h2>
    <p style="box-sizing: border-box; margin: 1em 0px; color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px;">The <span class="gmail-highlight gmail-preview_company_name" style="box-sizing: border-box; background: rgb(255, 255, 238);">&nbsp;Face Mask 99&nbsp;</span> is allowed to assign, transfer, and subcontract its rights and/or obligations under these Terms without any notification. However, you are not allowed to assign, transfer, or subcontract any of your rights and/or obligations under these Terms.</p>
    <h2 style="box-sizing: border-box; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; line-height: 1.1; color: rgb(51, 51, 51); margin: 0px 0px 1em; font-size: 20px;">Entire Agreement</h2>
    <p style="box-sizing: border-box; margin: 1em 0px; color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px;">These Terms constitute the entire agreement between <span class="gmail-highlight gmail-preview_company_name" style="box-sizing: border-box; background: rgb(255, 255, 238);">&nbsp;Face Mask 99&nbsp;</span> and you in relation to your use of this Website, and supersede all prior agreements and understandings.</p>
    <h2 style="box-sizing: border-box; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; line-height: 1.1; color: rgb(51, 51, 51); margin: 0px 0px 1em; font-size: 20px;">Governing Law &amp; Jurisdiction</h2>
    <li style="box-sizing: border-box; margin-top: 0.5em; margin-bottom: 0.5em;">We Are Located In Israel And Our Address is Ashkelon, Israel And Contact Phone Is: +972525005768</li>
    <p style="box-sizing: border-box; margin: 1em 0px; color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px;">These Terms will be governed by and interpreted in accordance with the laws of Europe, and you submit to the non-exclusive jurisdiction of the state and federal courts located in <span style="background-color: rgb(255, 255, 238);">Europe&nbsp;</span>for the resolution of any disputes.</p>
    
        </section>
        
        <div class="ct-cart" style="display:none !important;">
          <div class="ct-cart__inner">
            <div class="ct-cart__button ct-js-cart__button"><i class="fa fa-shopping-cart"></i></div>
            <div class="ct-cart__message"><i class="fa fa-thumbs-o-up"></i></div>
            <div class="ct-cart__product"></div>
          </div>
        </div>
        <div id="ct-js-wrapper" class="ct-js-wrapper ct-pageWrapper">
          <div class="row">
             <div class="col-md-4">
               
             </div>
             <div class="col-md-4">
          
             </div>
             <div class="col-md-4">
               
             </div>
           </div>
           <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <section data-parallax="100" data-background="assets/images/demo-content/smartwatch/section-background-8.jpg" data-height="100%" class="ct-u-display-table ct-mediaSection ct-u-padding-top-80 ct-u-padding-top-0-sm">
            <div class="inner">
              <div class="container">
    
              </div>
            </div>
            <div data-scroll="#product" class="ct-nextSection-scroll ct-js-nextSection-scroll animated pulse animation-infinity ct-nextSection-scroll--motive"><i class="fa fa-angle-double-down"></i><span>Continue</span></div>
          </section>
          
    <style>
    .button {
      background-color: #303030;
      border: none;
      color: white;
      padding: 15px 32px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 16px;
      margin: 4px 2px;
      cursor: pointer;
    }
    </style>
    
           <section data-background="#262626" id="contact">
            
            <div class="container">
              
              <div class="row ct-u-padding-top-80 ct-u-padding-bottom-75">
                <div class="col-md-4 col-sm-12"></div>
                <div class="col-md-4 col-sm-12">
                  <div class="ct-iconBox ct-iconBox--type4 media ct-iconBox--white">
                    <div class="media-left">
                      <div class="ct-iconBox-icon"><i class="fa fa-envelope-o"></i></div>
                    </div>
                    <div class="media-body">
                      <h6 class="ct-iconBox-title">Send Us a message</h6>
                      <p class="ct-iconBox-description"></p>
                    </div>
                  </div>
                </div>
                <div class="col-md-4 col-sm-12"></div>
                <div class="col-md-12 col-sm-12 ct-u-padding-top-25">
                  <div role="alert" style="display:none" class="successMessage alert alert-success alert-dismissible">Thank you. Your message has been sent correctly.
                    <button type="button" data-dismiss="alert" aria-hidden="true" aria-label="Close" class="close">x</button>
                  </div>
                  <div role="alert" style="display:none" class="successError alert alert-danger alert-dismissible">Ups! An error occured. Please try again later.
                    <button type="button" data-dismiss="alert" aria-hidden="true" aria-label="Close" class="close">x      </button>
                  </div>
                  <form action="" method="POST" class="ct-contactForm">
                    <div class="row">
                      <div class="col-sm-6">
                        <div class="form-group">
                          <input type="text" placeholder="Name*" id="cf-name" name="name" required="required" class="form-control"/>
                          <label for="cf-name" class="sr-only">Name*</label>
                        </div>
                      </div>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <input type="email" placeholder="Email address*" id="cf-email" name="email" required="required" class="form-control"/>
                          <label for="cf-email" class="sr-only">Email address*</label>
                        </div>
                      </div>
                     
                    </div>
                    <div class="row">
                      <div class="col-sm-6">
                        <div class="form-group">
                          <input type="tel" placeholder="Phone no" id="cf-phone" name="phone" class="form-control"/>
                          <label for="cf-phone" class="sr-only">Phone no</label>
                        </div>
                      </div>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <input type="text" placeholder="Subject*" id="cf-subject" name="subject" required="required" class="form-control"/>
                          <label for="cf-subject" class="sr-only">Subject*</label>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-sm-12">
                        <div class="form-group">
                          <textarea placeholder="Message*" id="cf-message" rows="1" required="required" class="form-control" name="msg"></textarea>
                          <div class="ct-contactForm-requiredMessage">*Marked fields are mandatory</div>
                          <button type="submit" class="btn btn--withIcon" name="senddata">Send message<i class="fa fa-caret-right"></i></button>
                          <label for="cf-message" class="sr-only">Message*</label>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </section>
          <div class="clearfix"></div>
          <form action="#" class="ct-searchForm">
            <div class="inner">
              <div class="container">
                <div class="row">
                  <div class="col-sm-8 col-sm-offset-2">
                    <div class="form-group">
                      <input id="cf-search-form" type="text" placeholder="Search on this site ..." required class="form-control">
                      <label for="cf-search-form" class="sr-only">Search on this site ...</label>
                      <button type="submit" class="ct-search-btn"><i class="fa fa-search"></i></button>
                    </div>
                    <div class="form-group"><a href="#" class="ct-searchForm-close">
                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="41px" height="41px" viewbox="0 0 41 41">
                          <path d="M 40.86 39.1C 40.86 39.1 39.77 40.19 39.77 40.19 39.77 40.19 20.83 21.24 20.83 21.24 20.83 21.24 1.88 40.19 1.88 40.19 1.88 40.19 0.8 39.1 0.8 39.1 0.8 39.1 19.74 20.16 19.74 20.16 19.74 20.16 0.81 1.23 0.81 1.23 0.81 1.23 1.9 0.14 1.9 0.14 1.9 0.14 20.83 19.07 20.83 19.07 20.83 19.07 39.76 0.14 39.76 0.14 39.76 0.14 40.84 1.23 40.84 1.23 40.84 1.23 21.92 20.16 21.92 20.16 21.92 20.16 40.86 39.1 40.86 39.1Z" fill="rgb(255,255,255)" opacity="0.50"></path>
                        </svg></a></div>
                  </div>
                </div>
              </div>
            </div>
          </form>
      
          <footer class="ct-footer">
            <div class="ct-footer-top">
              
              <nav class="ct-footer-nav">
                <div class="container">
                  <div class="row">
                    <div class="col-sm-4"></div>
                    <div class="col-sm-4">
                      <div class="widget">
                        <div class="widget-inner">
                          <img src="assets/images/products/logo.png" alt="">
                          
                      </div>
                    </div>
                    
                  </div>
                  <div class="col-sm-4"></div>
                </div>
              </nav>
            </div>
            <div class="ct-footer-bottom">
              <div class="container">
                <div class="row">
                  <div class="col-sm-12">
                    <div class="ct-payments">
                      <div class="row">
                        
                        <div class="col-md-12 col-sm-12">
                          <div class="widget">
                            <div class="widget-inner">
                              <div class="ct-payments-icons" style="text-align:center;color:white;"><span class="ct-payment-title" style="color:white;">We accept all populaR payment methods:</span><img src="assets/images/demo-content/drone/payment-icons.png" alt=""></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                     <div class="ct-footer-copyright">
                      <div class="row">
                        <div class="col-sm-7"><span class="ct-copyright-text">© 2013 All Rights Reserved To <a href="/" target="_blank">FACE MASK</a></span></div>
                        <div class="col-sm-5">
                          <ul class="list-inline list-unstyled ct-list-terms">
                            <li class="ct-productCart-link1 nav-item order_li"><a href="/" class="order_btn" style="border:1px solid #00bcdf;padding:8px;margin-top:20px;">HOME</a></li>
                            <li class="ct-productCart-link1 nav-item order_li"><a href="/terms.php" class="order_btn" style="border:1px solid #00bcdf;padding:8px;margin-top:20px;">TERMS</a></li>                           
                          </ul>
                        </div>
                      </div>
                    </div> 
                  </div>
                </div>
              </div>
            </div>
          </footer>
        </div>
        <!-- Mobile Menu //-->
        <div class="ct-menu-mobile">
          <nav class="navbar navbar-dark">
            <div class="container">
              <div class="row">
            
                <div class="col-xs-7 col-sm-4">
                  <div class="navbar-header"><a href="/" class="navbar-brand"><img src="assets/images/products/mobile_logo.png" alt="" style="width:225px !important;"></a></div>
                </div>
                <div class="col-xs-5 col-sm-4">
                  <ul role="menu" class="nav navbar-nav">
                    <li class="ct-productCart-link1"><a><i class="fa fa-shopping-cart"></i></a>
                    </li>
                    <li class="nav-item-toggle"><a><i class="fa fa-bars"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
          </nav>
        </div>
        <div class="navbar-beacon">
          <ul class="list-unstyled">
            <li class="nav-item"><a href="/">Home</a>
              </li>
              <li class="nav-item"><a href="#product" data-scroll="#product">Product</a></li>
              <li class="nav-item"><a href="#explanation" data-scroll="#explanation">Explanation</a></li>
              <li class="nav-item"><a href="#experience" data-scroll="#features">Mask Benefits</a></li>
              <li class="nav-item"><a href="#press_links" data-scroll="#press_links">Press Links</a>
              </li>
              <li class="nav-item"><a href="#contact" data-scroll="#contact">Contact</a></li>
              <li class="nav-item"><a href="#order" data-scroll="#order">Order now</a></li>
          </ul>
        <!--  <ul class="list-unstyled list-inline ct-socials--rounded">
            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
          </ul>-->
        </div>
        <!-- JavaScripts-->
        <script src="assets/js/disrupt.min.js"></script>
        <script src="assets/js/main.js"></script>
        <script src="assets/form/js/contact-form.js"></script>
        <!-- Plugins-->
      <!-- switcher -->
    
    <!-- end switcher -->
    </body>
    </html>
    
    
    <?php /**PATH E:\facemask\resources\views/terms.blade.php ENDPATH**/ ?>