<!-- top bar -->
       

<!-- Navigation-->

<nav data-background="#ffffff" data-height="80" class="navbar navbar-default navbar-fixed navbar-desktop navbar-wide">
    <div class="navbar-header"><a href="/" class="navbar-brand">
        <div class="inner" style="padding-top:10px;"><img src="assets/images/products/logo.png" alt="" style="width:225px !important;"></div></a>
               
    </div>
    
    <ul role="menu" class="ct-menu-mobile1 nav navbar-nav ct-navbar--fadeIn" style="float:left;padding-left:100px;">
      <li class="nav-item"><a href="/">Home</a>
      </li>
      <li class="nav-item"><a href="#N99 " data-scroll="#N99">N99</a></li>
      <li class="nav-item"><a href="#N95" data-scroll="#N95">N95 | 3M</a></li>
      <li class="nav-item"><a href="#pm25" data-scroll="#pm25">FFP3</a></li>
      <li class="nav-item"><a href="#explanation" data-scroll="#glasses">Glasses</a></li>
      <li class="nav-item"><a href="#experience" data-scroll="#gloves">Gloves</a></li>
      <li class="nav-item"><a href="#press_links" data-scroll="#gas">Gas Mask</a></li>
      <li class="nav-item"><a href="#contact" data-scroll="#contact">Contact</a></li>
      <li class="ct-productCart-link1 nav-item order_li"><a href="#order" class="order_btn" style="border:1px solid #00bcdf;padding:8px;margin-top:20px;">ORDER NOW</a></li>
      <li class="ct-productCart-link1 nav-item order_li"><a href="#" class="order_btn" style="border:1px solid #00bcdf;padding:8px;margin-top:20px;">Show Cart <i class="fa fa-shopping-cart"></i></a></li> 
    </ul>
          
  </nav><?php /**PATH E:\daily_work\facemask\resources\views/layouts/header.blade.php ENDPATH**/ ?>